# Power/Range Calculator
Generated: 2025-12-10T18:37:53.292546

## Power Savings Comparison

| Power Level | gr-sleipnir Equivalent | M17 Equivalent | Savings |
|-------------|------------------------|----------------|----------|
| 1W | 3.2W | 0.3W | 0.7W |
| 5W | 15.8W | 1.6W | 3.4W |
| 25W | 79.1W | 7.9W | 17.1W |
| 50W | 158.1W | 15.8W | 34.2W |

## Range Comparison

gr-sleipnir provides 1.78× more range than M17 at same power.
