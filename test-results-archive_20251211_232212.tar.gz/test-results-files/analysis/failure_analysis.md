# Failure Mode Analysis
Generated: 2025-12-10T18:37:52.589035

Total failures: 72/832 (8.7%)

## Failure Breakdown

FER failures: 61 (84.7% of failures)
WarpQ failures: 18 (25.0% of failures)

## Failure SNR Distribution

Mean SNR of failures: 8.5 dB
Median SNR of failures: 12.5 dB
Min SNR of failures: -5.0 dB
Max SNR of failures: 20.0 dB
