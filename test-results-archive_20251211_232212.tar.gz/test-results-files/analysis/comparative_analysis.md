# Comparative Analysis Preparation
Generated: 2025-12-10T18:37:52.588742

## gr-sleipnir Performance Metrics

- **4FSK Waterfall SNR**: Not achieved
- **Operational SNR (FER < 5%)**: 1.0 dB
- **FER Floor**: 4.9%

## Comparison to M17

| Metric | gr-sleipnir | M17 | Advantage |
|--------|-------------|-----|-----------|

## Power/Range Implications

