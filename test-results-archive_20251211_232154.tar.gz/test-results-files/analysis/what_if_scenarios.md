# 'What If' Scenarios
Generated: 2025-12-10T18:37:53.292670

## Soft-decision LDPC

**Change**: FER floor → 0%
**Impact**: Could achieve <1% FER at high SNR, competitive with M17

## 8FSK Waterfall +6 dB

**Change**: Worse than expected
**Impact**: 8FSK not competitive, stick with 4FSK

## Crypto Overhead 2 dB

**Change**: Higher than expected
**Impact**: Disable crypto by default, use only when needed

